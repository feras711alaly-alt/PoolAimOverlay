package com.example.poolaim

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "Pool Aim Overlay\n\nنسخة تجريبية"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val note = TextView(this).apply {
            text = "\nيعرض طبقة تصويب عائمة تجريبية. هذه النسخة لا تتعرف تلقائياً على الكرات بعد؛ يلزم تطوير واختبار معالجة صور الشاشة قبل الاعتماد على توقع التصادمات."
            textSize = 16f
            gravity = Gravity.CENTER
        }
        val permission = Button(this).apply {
            text = "السماح بالظهور فوق التطبيقات"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        val start = Button(this).apply {
            text = "تشغيل خطوط التصويب التجريبية"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, AimOverlayService::class.java))
                    finish()
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        }
        layout.addView(title)
        layout.addView(note)
        layout.addView(permission)
        layout.addView(start)
        setContentView(layout)
    }
}
