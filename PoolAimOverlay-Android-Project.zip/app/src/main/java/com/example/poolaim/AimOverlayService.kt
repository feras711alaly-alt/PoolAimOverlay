package com.example.poolaim

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

class AimOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: AimView? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = AimView()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(overlay, params)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        overlay?.let { wm.removeView(it) }
        overlay = null
        super.onDestroy()
    }

    inner class AimView : View(this@AimOverlayService) {
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.CYAN
            strokeWidth = 4f
            style = Paint.Style.STROKE
        }
        private val guide = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.YELLOW
            strokeWidth = 3f
            style = Paint.Style.STROKE
            pathEffect = android.graphics.DashPathEffect(floatArrayOf(14f, 10f), 0f)
        }
        private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 36f
            setShadowLayer(5f, 1f, 1f, Color.BLACK)
        }
        private var startX = 0f
        private var startY = 0f
        private var endX = 0f
        private var endY = 0f
        private var dragging = false

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (endX == 0f && endY == 0f) {
                startX = width * 0.25f
                startY = height * 0.60f
                endX = width * 0.80f
                endY = height * 0.35f
            }
            canvas.drawLine(startX, startY, endX, endY, line)
            canvas.drawText("خط تجريبي — اسحب لتغيير الاتجاه", 30f, 70f, label)
            // A dashed continuation illustrates the intended long guide only; it is not physics prediction.
            val dx = endX - startX
            val dy = endY - startY
            val length = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
            val farX = endX + dx / length * width * 0.6f
            val farY = endY + dy / length * width * 0.6f
            canvas.drawLine(endX, endY, farX, farY, guide)
            canvas.drawCircle(startX, startY, 13f, line)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.x; startY = event.y
                    endX = event.x + 180f; endY = event.y - 100f
                    dragging = true
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_MOVE -> if (dragging) {
                    endX = event.x; endY = event.y
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    dragging = false
                    invalidate()
                    return true
                }
            }
            return true
        }
    }
}
